/*

   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

 */
package org.apache.batik.anim;

import org.apache.batik.anim.values.AnimatableValue;
import org.apache.batik.anim.dom.AnimatableElement;
import org.apache.batik.anim.timing.TimedElement;

/**
 * An animation class for 'set' animations.
 *
 * @author <a href="mailto:cam%40mcc%2eid%2eau">Cameron McCormack</a>
 * @version $Id: SetAnimation.java 1733416 2016-03-03 07:07:13Z gadams $
 */
public class SetAnimation extends AbstractAnimation {

    /**
     * The set animation value.
     */
    protected AnimatableValue to;

    /**
     * Creates a new SetAnimation.
     */
    public SetAnimation(TimedElement timedElement,
                        AnimatableElement animatableElement,
                        AnimatableValue to) {
        super(timedElement, animatableElement);
        this.to = to;
    }

    /**
     * Called when the element is sampled at the given time.
     */
    protected void sampledAt(float simpleTime, float simpleDur,
                             int repeatIteration) {
        if (value == null) {
            value = to;
            markDirty();
        }
    }

    /**
     * Called when the element is sampled for its "last" value.
     */
    protected void sampledLastValue(int repeatIteration) {
        if (value == null) {
            value = to;
            markDirty();
        }
    }
}
