************
Bibliography
************

We recommand the following documents. Most of them were written with C
in mind, but should be easily adapted after you've read the rest of
this document.

* [1] "Gtk+/Gome Application Development" -- Havoc Pennington This book, by one
  of the main authors of the the GNOME environment, describes in detail some of
  the inner mechanisms of gtk+, including signal handling, and a complete
  description of all the widgets and all the events found in `Gdk.Event`.

  It is worth noting that this book has been published under the Open
  Publication License. You can get an electronic copy of it at
  `http://www.opencontent.org/ <http://www.opencontent.org/>`_.
