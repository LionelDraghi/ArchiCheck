Zip-Ada is a library for dealing with
the Zip compressed archive file format.

 - Fully open-source - no black-box
 - Fully in Ada
 - Fully portable - no preprocessing, conditionals

====
Complete description in: zipada.txt